# SeleniumCSharpNetCore
Selenium C# .NET Core 3.1 Basic course repo
